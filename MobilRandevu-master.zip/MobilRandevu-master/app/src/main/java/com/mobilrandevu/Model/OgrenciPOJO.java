package com.mobilrandevu.Model;

public class OgrenciPOJO {
    private int id;
    private String ogrenciNumarasi;
    private String adi;
    private String parola;


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getOgrenciNumarasi() {
        return ogrenciNumarasi;
    }

    public void setOgrenciNumarasi(String ogrenciNumarasi) {
        this.ogrenciNumarasi = ogrenciNumarasi;
    }

    public String getAdi() {
        return adi;
    }

    public void setAdi(String adi) {
        this.adi = adi;
    }

    public String getParola() {
        return parola;
    }

    public void setParola(String parola) {
        this.parola = parola;
    }
}
