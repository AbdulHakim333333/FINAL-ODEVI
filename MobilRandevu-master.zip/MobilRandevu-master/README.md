Akademisyen ve öğrenci arasındaki bir randevu uygulaması.

- Akademisyen ve öğrenci sisteme kaydolur.
- Öğrenci uygun akademisyeni ve takvimden uygun tarihi seçer randevusunu alır.
- Geçmiş ve gelecek randevularını soldan açılan menüden görebilir.
- Local database ile çalışmakta webservice kullanmadım.
- Eksiklikler ya da hatalar olabilir aceleyle bir arkadaşın proje ödevi için yazdım.

***Amacı ders geçmek olanlara ya da böyle proje yapacak olup örnek proje arayanlara yardımı dokunması ümidiyle.***
